#!/bin/bash
set -euxo pipefail

mkdir -p /var/log/signalfx/dotnet
chmod a+rwx /var/log/signalfx/dotnet
